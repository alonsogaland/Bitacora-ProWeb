<?php
// CONEXIÓN CON BASE DE DATOS
$servername = "localhost";
$username = "root";
$password = "";
$database = "alumno";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if (isset($_GET["id"])) {
    $id = intval($_GET["id"]); // Asegúrate de que el ID es un entero

    if ($id > 0) { // Verifica que el ID sea válido
        // ELIMINAR ALUMNO
        $stmt = $conn->prepare("DELETE FROM alumno WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            // Redirigir a la página principal después de eliminar
            header("Location: index.php?msg=deleted");
            exit(); // Salida inmediata después de redirigir
        } else {
            echo "<p style='color: red;'>Error: " . $stmt->error . "</p>"; // Mensaje de error
        }
        $stmt->close();
    } else {
        echo "<p style='color: red;'>ID de alumno no válido</p>"; // Mensaje de ID inválido
    }
} else {
    echo "<p style='color: red;'>ID de alumno no especificado</p>"; // Mensaje de ID no especificado
}

$conn->close();
?>
