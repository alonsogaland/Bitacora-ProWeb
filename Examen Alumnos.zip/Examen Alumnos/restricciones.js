function soloLetras(event) {
    var letra = event.keyCode;
    if ((letra > 64 && letra < 91) || (letra > 96 && letra < 123) || letra === 8 || letra === 32) {
        return true;
    } else {
        return false;
    }
}


function soloNumeros(event) {
    var tecla = event.keyCode;
    if ((tecla >= 48 && tecla <= 57) || tecla === 8) {
        return true;
    } else {
        return false;
    }
}


function fechaMayor1924(event) {
    var inputDate = new Date(event.target.value);
    var inputYear = inputDate.getFullYear();
    if (inputYear > 1924) {
        return true;
    } else {
        return false;
    }
}
