<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // RECIBE DATOS DEL FORMULARIO
    $id = $_POST['id'];
    $ncontrol = $_POST['ncontrol'];
    $nombre = $_POST['nombre'];
    $apaterno = $_POST['apaterno'];
    $amaterno = $_POST['amaterno'];
    $email = $_POST['email'];   
    $fecha = $_POST['fecha'];   

    // CONEXIÓN CON BASE DE DATOS
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "alumno";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // ACTUALIZAR DATOS
    $sql = "UPDATE alumno SET ncontrol='$ncontrol', nombre='$nombre', apaterno='$apaterno', amaterno='$amaterno', email='$email', fecha='$fecha' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Alumno actualizado exitosamente";
        echo "<a href='index.php'>Volver a la tabla</a>";
    } else {
        echo "Error al actualizar alumno: " . $conn->error; 
    }

    $conn->close();
} else {
    if (isset($_GET['id'])) {
        $id = $_GET['id']; 
        
        // CONEXIÓN CON BASE DE DATOS
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "alumno";

        $conn = new mysqli($servername, $username, $password, $database);

        // VERIFICACIÓN
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // OBTENER DATOS DEL USUARIO SELECCIONADO
        $sql = "SELECT ncontrol, nombre, apaterno, amaterno, email, fecha FROM alumno WHERE id=$id";
        $result = $conn->query($sql); 

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $ncontrol = $row['ncontrol'];
            $nombre = $row['nombre'];
            $apaterno = $row['apaterno'];
            $amaterno = $row['amaterno'];
            $email = $row['email']; 
            $fecha = $row['fecha'];
        ?>
            <script src="./restricciones.js"></script>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                Numero de Control: <input onkeydown="return soloNumeros(event);" required maxlength="8" type="number" name="ncontrol" value="<?php echo $ncontrol; ?>"><br>
                Nombre: <input onkeydown="return soloLetras(event);" required type="text" name="nombre" value="<?php echo $nombre; ?>"><br>
                Apellido Paterno: <input onkeydown="return soloLetras(event);" required type="text" name="apaterno" value="<?php echo $apaterno; ?>"><br>
                Apellido Materno: <input onkeydown="return soloLetras(event);" required type="text" name="amaterno" value="<?php echo $amaterno; ?>"><br>
                Email: <input required type="text" name="email" value="<?php echo $email; ?>"><br>
                Fecha de Nacimiento: <input onkeydown="return fechaMayor1924(event);" required type="date" name="fecha" value="<?php echo $fecha; ?>"><br>
                <input type="submit" value="Actualizar">
            </form>
        <?php
        } else {
            echo "No se encontró algún alumno.";
        }
        $conn->close();
    } else {
        echo "No se ha especificado un ID válido.";
    }
}
?>
