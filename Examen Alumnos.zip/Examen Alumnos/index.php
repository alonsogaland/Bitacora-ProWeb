<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- LLAMAR AL ARCHIVO CSS PARA DAR ESTILO  --> 
    <link rel="stylesheet" href="style.css">
    <title>EXAMEN DE ALUMNOS</title>
</head>
<body>

    <script src="./restricciones.js"></script>
    <h2>Nuevo alumno</h2>
    <form action="add.php" method="post">
        Numero de Control: <input onkeydown="return soloNumeros(event);" type="text" name="ncontrol" required maxlength="8">
        Nombre: <input type="text" name="nombre" onkeydown="return soloLetras(event);" required>
        Apellido Paterno: <input type="text" name="apaterno" onkeydown="return soloLetras(event);" required>
        Apelido Materno: <input type="text" name="amaterno" onkeydown="return soloLetras(event);" required>
        Email: <input type="text" name="email" required>
        Fecha de Nacimiento: <input onkeydown="return fechaMayor1924(event);" type="date" name="fecha" required>
        <input type="submit" value="Agregar usuario">
    </form>

    <hr>

    <h2>Alumnos</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Numero de Control</th>
            <th>Nombre</th>
            <th>Apellido Paterno</th>
            <th>Apellido Materno</th>
            <th>Email</th>
            <th>Fecha de Nacimiento</th>
            <th>Acciones</th>
        </tr>

        <?php
            // CONEXIÓN CON BASE DE DATOS
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "alumno";

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            // MOSTRAR LISTA DE ALUMNOS
            $sql = "SELECT id, ncontrol, nombre, apaterno, amaterno, email, fecha FROM alumno";
            $result = $conn->query($sql);

            // POBLAR TABLA
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["ncontrol"] . "</td>";
                    echo "<td>" . $row["nombre"] . "</td>";
                    echo "<td>" . $row["apaterno"] . "</td>";
                    echo "<td>" . $row["amaterno"] . "</td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["fecha"] . "</td>";                  //LISTO YA DEBE FUNCIONAR
                    echo "<td><a href='update.php?id=" . $row["id"] . "'>Editar</a> || <a href='delete.php?id=" . $row["id"] . "'>Eliminar</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr> <td colspan='8'>0 Resultados</td></tr>";
            }

            $conn->close();
        ?>
    </table>
</body>
</html>
