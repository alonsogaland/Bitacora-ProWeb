<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    //RECIBE DATOS DEL FORMULARIO
    $ncontrol = $_POST['ncontrol'];
    $nombre = $_POST['nombre'];
    $apaterno = $_POST['apaterno'];
    $amaterno = $_POST['amaterno'];
    $email = $_POST['email'];   
    $fecha = $_POST['fecha'];   
   
    //CONEXIÓN CON BASE DE DATOS
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "alumno";

    $conn = new mysqli($servername, $username, $password, $database);

    if($conn->connect_error){
        die("Conexión fallida: ".$conn->connect_error);
    }

    //TOCA INSERTAR EN TABLA DE USUARIOS 
    $sql = "INSERT INTO alumno (ncontrol, nombre, apaterno, amaterno, email, fecha) VALUES ('$ncontrol', '$nombre', '$apaterno', '$amaterno', '$email', '$fecha')";

    if($conn->query($sql) == TRUE){
        echo "Alumno creado exitosamente";
        echo "<a href=index.php>Volver a la tabla</a>";
    }else{
        echo "Error al crear alumno" . $con->error; 
    }
}

?>