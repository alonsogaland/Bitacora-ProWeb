<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    //RECIBE DATOS DEL FORMULARIO
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];   
   
    //CONEXIÓN CON BASE DE DATOS
    $servername = "localhost";
    $username = "id21899511_alonso";
    $password = "Arturo000$";
    $database = "id21899511_alonso";

    $conn = new mysqli($servername, $username, $password, $database);

    if($conn->connect_error){
        die("Conexión fallida: ".$conn->connect_error);
    }

    //ACTUALIZAR DATOS
    $sql = "UPDATE usuarios SET nombre='$nombre', email='$email' WHERE id=$id ";

    if($conn->query($sql) == TRUE){
        echo "Usuario actualizado exitosamente";
        echo "<a href=index.php>Volver a la tabla</a>";
    }else{
        echo "Error al actualizar usuario" . $con->error; 
    }

}else{
    if(isset($_GET['id'])){
        $id = $_GET['id']; 
        
        //CONEXIÓN CON BASE DE DATOS
        $servername = "localhost";
        $username = "id21899511_alonso";
        $password = "Arturo000$";
        $database = "id21899511_alonso";

        //VERIFICACIÓN
        if($conn->connect_error){
            die("Conexión fallida: ".$conn->connect_error);
        }

        //OBTENER DATOS DEL USUARIO SELECCIONADO
        $sql = "SELECT nombre, email FROM usuarios WHERE id=$id";
        $result = $conn->query($sql); 

        if($result->num_rows > 0){
            $row = $result ->fetch_assoc();
            $nombre = $row['nombre'];
            $email = $row['email']; 
        ?>
            <form method = "post" action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <input type = "hidden" name = "id" value = "<?php echo $id; ?>">
                Nombre: <input type = "text" name = "nombre" value = "<?php echo $nombre; ?>"><br>
                Email: <input type = "text" name = "email" value = "<?php echo $email; ?>"><br>
                <input type = "submit" value = "Actualizar">
            </form>
        <?php
        } else {
            echo "no se encontro algún usuario.";
        }
        $conn -> close();
        } else {
            echo "no se ha especificado un id valido.";
        }
}