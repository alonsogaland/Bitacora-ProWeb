<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>CRUD CON PHP Y MYSQL</title>
</head>
<body>
    
    <h2>Nuevo usuario</h2>
    <form action="crud.php" method="post">
        Nombre: <input type="text" name="nombre">
        Email: <input type="text" name="email">
        <input type="submit" name="Agregar usuario">
    </form>

    <hr>

    <h2>Usuarios</h2>
    <table border="1" >
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Acciones</th>
        </tr>

        <?php
            //CONEXIÓN CON BASE DE DATOS
            $servername = "localhost";
            $username = "id21899511_alonso";
            $password = "Arturo000$";
            $database = "id21899511_alonso";

            $conn = new mysqli($servername, $username, $password, $database);

            if($conn->connect_error){
                die("Conexión fallida: ".$conn->connect_error);
            }

            //MOSTRAR LISTA DE USUARIOS
            $sql = "SELECT id, nombre, email FROM usuarios";
            $result = $conn->query($sql);

            //POBLAR TABLA
            if($result->num_rows > 0){
                while($row = $result -> fetch_assoc()){
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["nombre"] . "</td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td><a href='editar.php?id = " . $row["id"] . "'> Editar </a> || <a href = 'delete.php?id = ". $row["id"] . "'> Eliminar </a></td>";
                    echo "</tr>";
                }

            }else{
                echo "<tr> <td colspan='4'>0 Resultados</td></tr>";
            }

        ?>

    </table>
</body>
</html>