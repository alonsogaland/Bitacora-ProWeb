<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    //RECIBE DATOS DEL FORMULARIO
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];   
   
    //CONEXIÓN CON BASE DE DATOS
    $servername = "localhost";
    $username = "id21899511_alonso";
    $password = "Arturo000$";
    $database = "id21899511_alonso";

    $conn = new mysqli($servername, $username, $password, $database);

    if($conn->connect_error){
        die("Conexión fallida: ".$conn->connect_error);
    }

    //TOCA INSERTAR EN TABLA DE USUARIOS 
    $sql = "INSERT INTO usuarios (nombre,email) VALUES ('$nombre', '$email')";

    if($conn->query($sql) == TRUE){
        echo "Usuario creado exitosamente";
        echo "<a href=index.php>Volver a la tabla</a>";
    }else{
        echo "Error al crear usuario" . $con->error; 
    }
}

?>