<?php
//if($_SERVER["REQUEST_METHOD"] == "POST"){
    //RECIBE DATOS DEL FORMULARIO
  //  $id = $_POST['id']; 
   
    //CONEXIÓN CON BASE DE DATOS
    $servername = "localhost";
    $username = "id21899511_alonso";
    $password = "Arturo000$";
    $database = "id21899511_alonso";

    $conn = new mysqli($servername, $username, $password, $database);

    if($conn->connect_error){
        die("Conexión fallida: " . $conn->connect_error);
    }else{

        if( ( $_SERVER["REQUEST_METHOD"]) == "GET" && isset($_GET['id'])  ){

            $id = $_GET['id']; 

            $sql = "DELETE FROM usuarios WHERE id = $id";
            
            if($conn->query($sql) === TRUE){
                echo "Usuario borrado exitosamente";
                echo "<a href=index.php>Volver a la tabla</a>";
            }else{
                echo "Error al borrar usuario" . $conn->error; 
            }

        }

    }

   // $conn->close();

    

//}
?>