// SELECCIONANDO TODOS LOS ELEMENTOS 
const start_btn = document.querySelector(".start_btn button");
const info_box = document.querySelector(".info_box");
const exit_btn = info_box.querySelector(".buttons .quit");
const continue_btn = info_box.querySelector(".buttons .restart");
const quiz_box = document.querySelector(".quiz_box");
const result_box = document.querySelector(".result_box");
const option_list = document.querySelector(".option_list");
const time_line = document.querySelector("header .time_line");
const timeText = document.querySelector(".timer .time_left_txt");
const timeCount = document.querySelector(".timer .timer_sec");

// SI SE DA CLIC EN EL BOTON DE INICIAR
start_btn.onclick = ()=>{
    info_box.classList.add("activeInfo"); // MOSTRAR CAJA DE INFORMACIÓN
}

// SI SE DA CLICKE N EL BOTON DE SALIR
exit_btn.onclick = ()=>{
    info_box.classList.remove("activeInfo"); // OCULTAR CAJA DE INFORMACIÒN
}

// if continueQuiz button clicked
continue_btn.onclick = ()=>{
    info_box.classList.remove("activeInfo"); // OCULTAR EL QUIZ BOX
    quiz_box.classList.add("activeQuiz"); // MOSTRAR EL QUIZ BOX
    showQuetions(0); // LLAMAR AL SHOW QUESTIONES METODO
    queCounter(1); // PARA 1 AL PARAMETRO
    startTimer(15); // LLAMA A LA FUNCION START TIMER
    startTimerLine(0); // LLAMA A LA FUNCION START TIMER LINE
}

let timeValue =  15;
let que_count = 0;
let que_numb = 1;
let userScore = 0;
let counter;
let counterLine;
let widthValue = 0;

const restart_quiz = result_box.querySelector(".buttons .restart");
const quit_quiz = result_box.querySelector(".buttons .quit");

// SI SE PICA AL BOTON DE REINICIO
restart_quiz.onclick = ()=>{
    quiz_box.classList.add("activeQuiz"); //MOSTRAR CUADRO DE CUESTIONARIO
result_box.classList.remove("activeResult"); //OCULTAR CUADRO DE RESULTADOS
timeValue = 15; 
que_count = 0;
que_numb = 1;
userScore = 0;
widthValue = 0;
showQuetions(que_count); //LLAMANDO A LA FUNCIÓN SHOWQUESTIONS
queCounter(que_numb); //PASANDO EL VALOR DE QUE_NUMB A QUECOUNTER
clearInterval(counter); //LIMPIAR CONTADOR
clearInterval(counterLine); //LIMPIAR COUNTERLINE
startTimer(timeValue); //LLAMANDO A LA FUNCIÓN STARTTIMER
startTimerLine(widthValue); //LLAMANDO A LA FUNCIÓN STARTTIMERLINE
timeText.textContent = "Restante"; //CAMBIAR EL TEXTO DE TIMETEXT A "RESTANTE"
next_btn.classList.remove("show"); //OCULTAR EL BOTÓN SIGUIENTE
}
// SI EL BOTÓN QUITQUIZ ES PRESIONADO
quit_quiz.onclick = ()=>{
    window.location.reload(); //RECARGAR LA VENTANA ACTUAL
}

const next_btn = document.querySelector("footer .next_btn");
const bottom_ques_counter = document.querySelector("footer .total_que");

// SI EL BOTÓN SIGUIENTE ES PRESIONADO
next_btn.onclick = ()=>{
    if(que_count < questions.length - 1){ //SI EL CONTADOR DE PREGUNTAS ES MENOR QUE LA LONGITUD TOTAL DE PREGUNTAS
        que_count++; //INCREMENTAR EL VALOR DE QUE_COUNT
        que_numb++; //INCREMENTAR EL VALOR DE QUE_NUMB
        showQuetions(que_count); //LLAMANDO A LA FUNCIÓN SHOWQUESTIONS
        queCounter(que_numb); //PASANDO EL VALOR DE QUE_NUMB A QUECOUNTER
        clearInterval(counter); //LIMPIAR CONTADOR
        clearInterval(counterLine); //LIMPIAR COUNTERLINE
        startTimer(timeValue); //LLAMANDO A LA FUNCIÓN STARTTIMER
        startTimerLine(widthValue); //LLAMANDO A LA FUNCIÓN STARTTIMERLINE
        timeText.textContent = "Restante"; //CAMBIAR TIMETEXT A "RESTANTE"
        next_btn.classList.remove("show"); //OCULTAR EL BOTÓN SIGUIENTE
    }else{
        clearInterval(counter); //LIMPIAR CONTADOR
        clearInterval(counterLine); //LIMPIAR COUNTERLINE
        showResult(); //LLAMANDO A LA FUNCIÓN SHOWRESULT
    }
}

// OBTENER PREGUNTAS Y OPCIONES DEL ARREGLO
function showQuetions(index){
    const que_text = document.querySelector(".que_text");

    //CREAR UNA NUEVA ETIQUETA SPAN Y DIV PARA LA PREGUNTA Y OPCIONES Y PASAR EL VALOR USANDO EL ÍNDICE DEL ARREGLO
    let que_tag = '<span>'+ questions[index].numb + ". " + questions[index].question +'</span>';
    let option_tag = '<div class="option"><span>'+ questions[index].options[0] +'</span></div>'
    + '<div class="option"><span>'+ questions[index].options[1] +'</span></div>'
    + '<div class="option"><span>'+ questions[index].options[2] +'</span></div>'
    + '<div class="option"><span>'+ questions[index].options[3] +'</span></div>';
    que_text.innerHTML = que_tag; //AÑADIR NUEVA ETIQUETA SPAN DENTRO DE QUE_TAG
    option_list.innerHTML = option_tag; //AÑADIR NUEVA ETIQUETA DIV DENTRO DE OPTION_TAG
    
    const option = option_list.querySelectorAll(".option");

    // ESTABLECER EL ATRIBUTO ONCLICK A TODAS LAS OPCIONES DISPONIBLES
    for(i=0; i < option.length; i++){
        option[i].setAttribute("onclick", "optionSelected(this)");
    }
}
// CREAR NUEVAS ETIQUETAS DIV PARA LOS ICONOS
let tickIconTag = '<div class="icon tick"><i class="fas fa-check"></i></div>';
let crossIconTag = '<div class="icon cross"><i class="fas fa-times"></i></div>';

//SI EL USUARIO PRESIONA UNA OPCIÓN
function optionSelected(answer){
    clearInterval(counter); //LIMPIAR CONTADOR
    clearInterval(counterLine); //LIMPIAR COUNTERLINE
    let userAns = answer.textContent; //OBTENER LA OPCIÓN SELECCIONADA POR EL USUARIO
    let correcAns = questions[que_count].answer; //OBTENER LA RESPUESTA CORRECTA DEL ARREGLO
    const allOptions = option_list.children.length; //OBTENER TODOS LOS ELEMENTOS DE OPCIÓN
    
    if(userAns == correcAns){ //SI LA OPCIÓN SELECCIONADA POR EL USUARIO ES IGUAL A LA RESPUESTA CORRECTA DEL ARREGLO
        userScore += 1; //AUMENTAR EL VALOR DE LA PUNTUACIÓN EN 1
        answer.classList.add("correct"); //AÑADIR COLOR VERDE A LA OPCIÓN CORRECTA SELECCIONADA
        answer.insertAdjacentHTML("beforeend", tickIconTag); //AÑADIR ICONO DE TICK A LA OPCIÓN CORRECTA SELECCIONADA
        console.log("Correct Answer");
        console.log("Your correct answers = " + userScore);
    }else{
        answer.classList.add("incorrect"); //AÑADIR COLOR ROJO A LA OPCIÓN INCORRECTA SELECCIONADA
        answer.insertAdjacentHTML("beforeend", crossIconTag); //AÑADIR ICONO DE CRUZ A LA OPCIÓN INCORRECTA SELECCIONADA
        console.log("Wrong Answer");

        for(i=0; i < allOptions; i++){
            if(option_list.children[i].textContent == correcAns){ //SI HAY UNA OPCIÓN QUE COINCIDE CON LA RESPUESTA DEL ARREGLO
                option_list.children[i].setAttribute("class", "option correct"); //AÑADIR COLOR VERDE A LA OPCIÓN COINCIDENTE
                option_list.children[i].insertAdjacentHTML("beforeend", tickIconTag); //AÑADIR ICONO DE TICK A LA OPCIÓN COINCIDENTE
                console.log("Auto selected correct answer.");
            }
        }
    }
    for(i=0; i < allOptions; i++){
        option_list.children[i].classList.add("disabled"); //UNA VEZ QUE EL USUARIO SELECCIONA UNA OPCIÓN, DESHABILITAR TODAS LAS OPCIONES
    }
    next_btn.classList.add("show"); //MOSTRAR EL BOTÓN SIGUIENTE SI EL USUARIO SELECCIONÓ ALGUNA OPCIÓN
}

function showResult(){
    info_box.classList.remove("activeInfo"); //OCULTAR EL CUADRO DE INFORMACIÓN
    quiz_box.classList.remove("activeQuiz"); //OCULTAR EL CUADRO DE CUESTIONARIO
    result_box.classList.add("activeResult"); //MOSTRAR EL CUADRO DE RESULTADOS
    const scoreText = result_box.querySelector(".score_text");
    if (userScore > 3){ // SI EL USUARIO OBTUVO MÁS DE 3 PUNTOS
        //CREAR UNA NUEVA ETIQUETA SPAN Y PASAR EL NÚMERO DE PUNTOS DEL USUARIO Y EL NÚMERO TOTAL DE PREGUNTAS
        let scoreTag = '<span>Felicidades 🎉, obtuviste <p>'+ userScore +'</p> de <p>'+ questions.length +'</p></span>';
        scoreText.innerHTML = scoreTag;  //AÑADIR NUEVA ETIQUETA SPAN DENTRO DE SCORE_TEXT
    }
    else if(userScore > 1){ // SI EL USUARIO OBTUVO MÁS DE 1 PUNTO
        let scoreTag = '<span>Bien, obtuviste <p>'+ userScore +'</p> de <p>'+ questions.length +'</p></span>';
        scoreText.innerHTML = scoreTag;
    }
    else{ // SI EL USUARIO OBTUVO MENOS DE 1 PUNTO
        let scoreTag = '<span>Lo sentimos, obtuviste <p>'+ userScore +'</p> de <p>'+ questions.length +'</p></span>';
        scoreText.innerHTML = scoreTag;
    }
}

function startTimer(time){
    counter = setInterval(timer, 1000);
    function timer(){
        timeCount.textContent = time; //CAMBIAR EL VALOR DE TIMECOUNT POR EL VALOR DEL TIEMPO
        time--; //DECREMENTAR EL VALOR DEL TIEMPO
        if(time < 9){ //SI EL TIEMPO ES MENOR QUE 9
            let addZero = timeCount.textContent; 
            timeCount.textContent = "0" + addZero; //AÑADIR UN 0 ANTES DEL VALOR DEL TIEMPO
        }
        if(time < 0){ //SI EL TIEMPO ES MENOR QUE 0
            clearInterval(counter); //LIMPIAR CONTADOR
            timeText.textContent = "Time Off"; //CAMBIAR EL TEXTO DE TIEMPO A "TIME OFF"
            const allOptions = option_list.children.length; //OBTENER TODOS LOS ELEMENTOS DE OPCIÓN
            let correcAns = questions[que_count].answer; //OBTENER LA RESPUESTA CORRECTA DEL ARREGLO
            for(i=0; i < allOptions; i++){
                if(option_list.children[i].textContent == correcAns){ //SI HAY UNA OPCIÓN QUE COINCIDE CON LA RESPUESTA DEL ARREGLO
                    option_list.children[i].setAttribute("class", "option correct"); //AÑADIR COLOR VERDE A LA OPCIÓN COINCIDENTE
                    option_list.children[i].insertAdjacentHTML("beforeend", tickIconTag); //AÑADIR ICONO DE TICK A LA OPCIÓN COINCIDENTE
                    console.log("Time Off: Auto selected correct answer.");
                }
            }
            for(i=0; i < allOptions; i++){
                option_list.children[i].classList.add("disabled"); //UNA VEZ QUE EL USUARIO SELECCIONA UNA OPCIÓN, DESHABILITAR TODAS LAS OPCIONES
            }
            next_btn.classList.add("show"); //MOSTRAR EL BOTÓN SIGUIENTE SI EL USUARIO SELECCIONÓ ALGUNA OPCIÓN
        }
    }
}

function startTimerLine(time){
    counterLine = setInterval(timer, 29);
    function timer(){
        time += 1; //AUMENTAR EL VALOR DEL TIEMPO EN 1
        time_line.style.width = time + "px"; //AUMENTAR EL ANCHO DE TIME_LINE EN PX POR EL VALOR DEL TIEMPO
        if(time > 549){ //SI EL VALOR DEL TIEMPO ES MAYOR QUE 549
            clearInterval(counterLine); //LIMPIAR COUNTERLINE
        }
    }
}

function queCounter(index){
    //CREAR UNA NUEVA ETIQUETA SPAN Y PASAR EL NÚMERO DE PREGUNTA Y EL TOTAL DE PREGUNTAS
    let totalQueCounTag = '<span><p>'+ index +'</p> de <p>'+ questions.length +'</p> Preguntas </span>';
    bottom_ques_counter.innerHTML = totalQueCounTag;  //AÑADIR NUEVA ETIQUETA SPAN DENTRO DE BOTTOM_QUES_COUNTER
}
