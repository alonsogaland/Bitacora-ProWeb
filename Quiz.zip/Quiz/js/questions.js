// Crear el array seleccionando el numero, pregunta, respuesta y opciones (en ese orden)
let questions = [
    {
    numb: 1,
    question: "¿Cómo se llama el profe?",
    answer: "Arturo Aguilera Vazquez",
    options: [
      "Arturo Aguilar Velazquez",
      "Arturo Aguilar Vazquez",
      "Arturo Aguilera Vazquez",
      "Arturo Aguilera Velazquez"
    ] 
  },
    {
    numb: 2,
    question: "¿Cuál es el deporte favorito de Alonso?",
    answer: "Basquetbol",
    options: [
      "Futbol",
      "Beisbol",
      "Basquetbol",
      "Voileibol"
    ]
  },
    {
    numb: 3,
    question: "¿En qué salón tenemos la clase?",
    answer: "LCR",
    options: [
      "LCE",
      "LCR",
      "Valerdi",
      "LCI"
    ]
  },
    {
    numb: 4,
    question: "¿Cómo se llama la academia del profe?",
    answer: "Academia de artes sonoras",
    options: [
      "Academia de musica sonora",
      "Academia de artes sonoras",
      "Academia musical y de artes sonoras",
      "Academia artistica sonora"
    ]
  },
    {
    numb: 5,
    question: "¿El Koke va reprobar Pro Web?",
    answer: "Tal vez",
    options: [
      "Si :(",
      "No :)",
      "Tal vez",
      "Ya esta reprobado"
    ]
  },
];